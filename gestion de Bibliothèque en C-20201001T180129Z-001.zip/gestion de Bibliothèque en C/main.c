#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "Bib_LLC_BIBLIO.h"
#include <stdio.h>
#include <windows.h>
#include "conio.h"
#include"graphisme.h"
#define MAX 1000

int main()
{
    system("mode con LINES=50 COLS=90");            //On Donne une taille au programme
    int a,jj,mm,aa;
    struct list_livre *tete=NULL,*tete5=NULL ;
    M_emprunt *te=NULL,*tet=NULL,*t1,*t2;
    M_emprunteur *tete1=NULL;
    FILE*F1=fopen("liste des livres2.txt","r");
    FILE*F2=fopen("liste des emprunteurs2.txt","r");
    FILE*F3=fopen("liste des emprunts2.txt","r");



    if ( F1 ==NULL || F2 ==NULL || F3 ==NULL )
    {
        lire_fich_emprunt(&te) ; //lire le fichier d'emprunt donn�
        init_emprunt(&te) ; // ecrire dans un fichier secondaire qui contient autre champs
        init_fich(&tete1,te) ; // lire le fichier d'emprunteurs donn� et ecrire dans un autre fichier
        lire_fich1(&tete5) ; // lire le fichier des livres donn�
        Init_fich_sec(&tete5,te) ; //ecrire dans un autre fichier secondaire
    }
    fclose(F1);
    fclose(F2);
    fclose(F3);

    tet = NULL ;
    tete = NULL ;
    tete1 = NULL ;

    lire_fich_emprunt1(&tet) ; // lire le fichier secondaire et la liste d'emprunt utile
    initialiser(&tete1) ;// lire la liste utile d'emprunteurs
    lire_fich2(&tete) ;//initialiser la liste des livres utile
    mis_a_jour_pina(tet,tete1);

    begining();  //graphisme de d�but
    do
    {
        choix_menu(&a);
        switch (a)
        {
            case 1: {
                gotoxy(30,1) ;
                textbackground(BLACK);
                textcolor(LIGHTCYAN);
                printf("Inscription \n") ;
                textcolor(WHITE);
                inscription(&tete1) ;   //ajouter un nouveau emprunteur
                printf("\n") ;
                printf("\n ") ;
                printf("\n\n");
                system("pause");
            }
            break;
            case 2: {
                gotoxy(30,1);
                textbackground(BLACK);
                textcolor(LIGHTCYAN);
                mis_a_jour_pina(tet,tete1);
                printf("Emprunter un Livre\n") ;
                emprunter(tete,tete1,&tet) ;
                textcolor(LIGHTCYAN);
                printf("\n\n");
                system("pause");
            }
            break;
            case 3: {
                gotoxy(30,1);
                textbackground(BLACK);
                textcolor(LIGHTCYAN);
                printf("Restituer un livre\n") ;
                restitution(tete,tet,tete1) ;
                textcolor(WHITE);
                printf("\n\n");
                system("pause");
            }
            break;
            case 4:{
                gotoxy(20,1);
                textbackground(BLACK);
                textcolor(LIGHTCYAN);
                printf("Le Nombre D'emprunt Par Emprunteurs\n") ;
                printf("\n\n") ;
                emprunt_emprunteurs(tet,tete1) ;
                textcolor(WHITE);
                printf("\n\n");
                system("pause");
            }
            break;
            case 5 : {
                gotoxy(10,1);
                textbackground(BLACK);
                textcolor(LIGHTCYAN);
                printf("la liste des livres tri\202e selon leur nombre d'emprunt\n");
                printf("\n\n");
                affich_list_tri(tete,tet);
                textcolor(WHITE);
                system("pause");
            }
            break;
            case 6: {
                gotoxy(25,1);
                textbackground(BLACK);
                textcolor(LIGHTCYAN);
                printf("Les emprunts en cours\n");
                printf("\n\n");
                affich_indisponible(tete,tete1,tet);
                printf("\n") ;
                textcolor(WHITE);
                system("pause");
            }
            break;
            case 7:{
                gotoxy(20, 1);
                textbackground(BLACK);
                textcolor(LIGHTCYAN);
                mis_a_jour_pina(tet,tete1);
                printf("La liste des emprunteurs p\202nalis\202s\n") ;
                printf("\n\n");
                affich_pinailite(tete1,tet);
                textcolor(WHITE);
                printf("\n\n");
                system("pause");
            }
            break;
            case 8:{

                gotoxy(20, 1);
                textbackground(BLACK);
                textcolor(LIGHTCYAN);
                printf("Eclatement De La Liste des Emprunts\n") ;
                printf("\n\n");
                eclat_list(tet,&t1,&t2) ;
                textcolor(WHITE);
                gotoxy(5, 5);
                printf(" L'enregistrement dans le fichier est  R\202ussi \n") ;
                 gotoxy(5, 6);
                printf("Veuillez V\202rifier le fichier : Eclatement de la liste\n");
                 printf("\n ") ;
                system("pause");
            }
            break;
            case 9:{
                gotoxy(25,1);
                textbackground(BLACK);
                textcolor(LIGHTCYAN);
                printf("Recherche Par Auteur\n") ;
                printf("\n\n");
                recotr(tete) ;
                textcolor(WHITE);
                printf("\n");
                system("pause");
            }
            break;
            case 10:{
                gotoxy(25, 1);
                textbackground(BLACK);
                textcolor(LIGHTCYAN);
                printf("Recherche Par Mots Cl\202s\n");
                printf("\n\n");
                recherch_par_motcles(tete) ;
                textcolor(WHITE);
                printf("\n");
                system("pause");
            }
            break;
        }
    }
    while (a != 11 );      //On revient au menu jusqu' on d�cide de quitter le programme
    enregistrer(tete,tete1,tet) ;//Initialiser les fichiers secondaires pour sauvegarder les donn�es d'execution et les utiliser prochainement
    ending(); //graphisme de fin*/
    return 0;
}

