#include <stdio.h>
#include <stdlib.h>
#include "conio.h"
#define down 80             //code ascii de la touche bas
#define up 72              //code ascii de la touche haut
#define entr 13            //code ascii de la touche entr�e

void choix_menu (int *choice)
/**Procedure d'ffichage du menu qu'on parcoure avec les fleches bidirectionnelles et qui retourne le choix**/
{
    char choix[][100]={
        "Inscription",
        "Emprunter Un Livre",
        "Restituer Un Livre",  //tableau contenant les choix
        "Afficher Le Nombre D'emprunt Par Emprunteur",
      "Afficher la liste des livres tri\202e selon leur nombre d'emprunt",
      "Afficher le Nom d'emrunteur,Date de Retour des emprunts en cours",
       "Afficher la liste des emprunteurs p\202nalis\202s",
       "Eclater La Liste Des Emprunts Selon le critere ",
       "Rechercher Un Livre Par Auteur",
        "Rechercher Un Livre Par Mots Cl\202s",
        "Quitter",
          };
    int i, x= 13, y = 16;  //x et y sont les coordonn�es du point o� commence le menu
    char point, point2;
    acc();                 //Donne au programme sa forme g�n�rale
    gotoxy(30, 12);
    textbackground(BLACK);
    textcolor(LIGHTCYAN);
    printf(" Menu Principal ");       //titre du menu
    textcolor(WHITE);
    for (i=0; i<11; i++)
    {
        gotoxy(x,i+y);                   //On �crit les diff�rents choix du menu chacun dans une ligne
        printf("%s", choix[i]);
    }
    gotoxy(x,y);
    textcolor(YELLOW);
    printf("%s", choix[0]);               //On r��crit la premiere ligne en bleu (s�l�ction)
    do
    {
        point = getch();                 //lire le code ascii d'une touche du clavier
        if (point == entr) *choice = wherey() -y+1;       // la touche entr�e permet de valider le choix selectionn�
        else if (point == -32)   //la touche est une des fl�ches bidirectionnelles
        {
            point2 = getch();
            switch (point2)
            {
                case up :
                    {
                        if (wherey() == y)           //si la selection est en haut et que la fl�che est vers le haut
                        {                            //la selection pointe sur le dernier choix
                            gotoxy(x,y);
                            textcolor(WHITE);       //On d�selectionne le premier choix
                            printf("%s", choix[0]);
                            gotoxy(x,i+y-1);
                            textcolor(YELLOW);
                            printf("%s", choix[10]);     //On selectionne le dernier
                        }

                        else
                        {                                               //Sinon la selection passe vers la ligne suivante
                            gotoxy(x, wherey());
                            textcolor(WHITE);
                            printf("%s", choix[wherey()-y]);        //D�selection
                            gotoxy(x, wherey()-1);
                            textcolor(YELLOW);
                            printf("%s", choix[wherey()-y]);
                        }
                    }
                break;
                case down :
                    {
                        if (wherey() == y+10)                //si la selection est en bas et que la fl�che est vers le bas
                        {                                  //la selection pointe sur le premier choix
                            gotoxy(x,y+10);
                            textcolor(WHITE);
                            printf("%s", choix[10]);
                            gotoxy(x,y);
                            textcolor(YELLOW);
                            printf("%s", choix[0]);
                        }
                        else                                            //Sinon,la selection passe vers la ligne pr�c�dante
                        {
                            gotoxy(x, wherey());
                            textcolor(WHITE);
                            printf("%s", choix[wherey()-y]);
                            gotoxy(x, wherey()+1);
                            textcolor(YELLOW);
                            printf("%s", choix[wherey()-y]);
                        }
                    }
                break;
            }
        }
    }
    while (point != entr )  ;      //on continue de lire jusqu'� ce que le choix est valid�
    system("cls");
    textcolor(LIGHTCYAN);
}

void acc()
/**Donne la forme g�n�rale du programme**/
{
    int i=rand(); //g�n�ration d'un nombre al�atoir
    system("color 66");     //couleur de fond et de texte
    system("cls");
    gotoxy(1,3);
    printf("_________________________________________________________________________________________");
    gotoxy(1,5);
    printf("    TP1 ALSDD        |       Belaribi Nadjib & Mouaci Youcef      |        2016/2017  ");
    gotoxy(1,7);
    printf("_________________________________________________________________________________________");

}

void begining () /**graphisme de d�but**/
{
    int i;
    system ("color 44");
    gotoxy (15,5);
    printf ("   \333\333\333\333\333\333\333\333\333\333\333\333\333\333      \333\333\333\333\333\333\333\333\333\333\333\333\333\333      \333\333\333\n");
    gotoxy (15,6);
    printf ("   \333\333\333\333\333\333\333\333\333\333\333\333\333\333      \333\333\333\333\333\333\333\333\333\333\333\333\333\333      \333\333\333\n");
    gotoxy (15,7);
    printf ("   \333\333\333                 \333\333\333                                       \n");
    gotoxy (15,8);
    printf ("   \333\333\333                 \333\333\333      \n");
    gotoxy (15,9);
    printf ("   \333\333\333                 \333\333\333                 \333\333\333\n");
    gotoxy (15,10);
    printf ("   \333\333\333                 \333\333\333                 \333\333\333\n");
    gotoxy (15,11);
    printf ("   \333\333\333                 \333\333\333                 \333\333\333\n");
    gotoxy (15,12);
    printf ("   \333\333\333                 \333\333\333                 \333\333\333\n");
    gotoxy (15,13);
    printf ("   \333\333\333\333\333\333\333\333\333\333\333\333\333\333      \333\333\333\333\333\333\333\333\333\333\333\333\333\333      \333\333\333\n");
    gotoxy (15,14);
    printf ("   \333\333\333\333\333\333\333\333\333\333\333\333\333\333      \333\333\333\333\333\333\333\333\333\333\333\333\333\333      \333\333\333\n");
    gotoxy (15,15);
    printf ("   \333\333\333                            \333\333\333      \333\333\333\n");
    gotoxy (15,16);
    printf ("   \333\333\333                            \333\333\333      \333\333\333\n");
    gotoxy (15,17);
    printf ("   \333\333\333                            \333\333\333      \333\333\333\n");
    gotoxy (15,18);
    printf ("   \333\333\333                            \333\333\333      \333\333\333\n");
    gotoxy (15,19);
    printf ("   \333\333\333                            \333\333\333      \333\333\333\n");
    gotoxy (15,20);
    printf ("   \333\333\333                            \333\333\333      \333\333\333\n");
    gotoxy (15,21);
    printf ("   \333\333\333\333\333\333\333\333\333\333\333\333\333\333      \333\333\333\333\333\333\333\333\333\333\333\333\333\333      \333\333\333\n");
    gotoxy (15,22);
    printf ("   \333\333\333\333\333\333\333\333\333\333\333\333\333\333      \333\333\333\333\333\333\333\333\333\333\333\333\333\333      \333\333\333\n");
    gotoxy(10,25);
    textcolor (LIGHTCYAN);
    for (i=0; i<54;i++)
    {
        printf("\333");
        delay (15);
    }
    textbackground(BLACK);
    textcolor(LIGHTCYAN);
    gotoxy (5,29);
    printf (" Automatiser Le Fonctionnement D'une Bibliotheque ");
    gotoxy (2,32);
    system ("pause");
    system ("cls");
}

void ending() /**Graphisme de fin**/
{

    system("cls");
    textcolor(LIGHTCYAN);
    gotoxy(1,10);
    printf("                ######      ######                           ###   \n");
    delay(5);
    printf("                   ####      #####                            #### \n ");
    delay(5);
    printf("                  #####     #####                            ###\n ");
    delay(5);
    printf("                  #####    #####                                  \n ");
    delay(5);
    printf("                  #####   #####     ####  #### ###   ##### ####= \n");
    delay(5);
    printf("                   # ####  # ###   ####### ######## #######  ###= \n ");
    delay(5);
    printf("                  #  #### ## ###   ###  ## #######  ###.  ## ###=\n ");
    delay(5);
    printf("                  #  ######  ###   ###  ### ####    ###   ## ###=\n");
    delay(5);
    printf("                   #  ######  ###   ######## ####    ###      ###= \n  ");
    delay(5);
    printf("                 #   ####   ###   ###      ###/    ###      ###= \n");
    delay(5);
    printf("                   #   ####   ###   ###      ####    ####     ###= \n  ");
    delay(5);
    printf("                 #    ##    ###   ####  ## ####    ####   # ###= \n");
    delay(5);
    printf("                   #    ##    ####  /###### .####     #######.#### .\n  ");
    delay(5);
    printf("              #####   ##  ########.#####. ######.   ######.######.\n");
    gotoxy (3,30);
    system("pause");
}

