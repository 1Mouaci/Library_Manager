struct livre
{
    int cote ;
    char titre[100] ;
    char auteur [30];
    int date_edit ;
    char editeur[50];
    char t[100];
    char resume [400];
    int disponible;
    int help ;// Donne la taille du tableau des mots_cl�s (pour l'affichage)
};
struct list_livre
{
  struct livre  livre ;
  struct list_livre *next ;
};


typedef struct date date ; //Pour Calculer la diff�recnce entre deux dates
struct date
{
    int jour ;
    int mois ;
    int anne ;
};


typedef struct M_emprunteur M_emprunteur;
struct M_emprunteur
{
    char          nom[15];
    char          prenom[15];
    char          n_tep[15] ;
    int           n_ord ;
    char          adress[25] ;
    char          pr_ins[sizeof "JJ/MM/AAAA"];/* Creer une chaine JJ/MM/AAAA*/
    int           pinalite ;
    int           prend ;
    M_emprunteur  *suiv;
};

typedef struct M_emprunt M_emprunt;
struct M_emprunt
{
    int       cot_livre;
    int       n_emp;
    char      dat_emprunt[sizeof "JJ/MM/AAAA"];
    date      d_limite ;
    int       rendu ;
    M_emprunt *suit ;

};
struct tri_livres      // Utile pour trier la liste des livres
{
    char titre [100] ;
    int occurence ;
};
/*************** Modele LlC *******************/
//Livres
struct list_livre *allouer() ;
void aff_adr(struct list_livre *p,struct list_livre *q);
int valeur_cote(struct list_livre* tete ) ;
char valeur_titre(struct list_livre* tete) ;
int valeur_cote(struct list_livre* tete ) ;
char valeur_titre(struct list_livre* tete) ;
int valeur_date_edit(struct list_livre* tete) ;
void aff_cote (struct list_livre *lv ,int cot ) ;
void aff_titre(struct list_livre *lv, char titr[100]) ;
void aff_auteur(struct list_livre *lv ,char oteur[30]) ;
void aff_date_edit(struct list_livre *lv,int date) ;
void aff_editeur(struct list_livre *lv,char editr[50]) ;
void aff_resume(struct list_livre *lv,char resum [400]) ;

//EMPRUNTEUR ;
void Alo_emprunteur(M_emprunteur **p);
void libere(M_emprunteur *p) ;
void Aff_nom(M_emprunteur *p,char n[]);
void Aff_pre(M_emprunteur *p,char n[]) ;
void Aff_tep(M_emprunteur *p,char n[]) ;
void Aff_rue(M_emprunteur *p,char n[]) ;
void Aff_vil(M_emprunteur *p,char n[]) ;
void Aff_mais(M_emprunteur *p,int n) ;
void Aff_ord(M_emprunteur *p,int n) ;
void Aff_ins (M_emprunteur *p,char n[]) ;
void Aff_adr(M_emprunteur *P, M_emprunteur *Q);
void aff_prend(M_emprunteur *p,int n) ;
char* nom(M_emprunteur *p) ;
char* prenom (M_emprunteur *p);
char* telephon(M_emprunteur *p);
int n_ordre(M_emprunteur *p) ;
char* pre_ins(M_emprunteur *p) ;
int prend (M_emprunteur *p) ;
M_emprunteur* suiv(M_emprunteur *p) ;
//EMPRUNT
void Alo_emprunt (M_emprunt **p) ;
void aff_co_livre(M_emprunt *p,int n) ;
void aff_n_emp(M_emprunt *p,int n);
void aff_demprunt(M_emprunt *p,char n[]) ;
void aff_preretour(M_emprunt *p,int j,int m,int a );
void aff_efective(M_emprunt *p,char n[]) ;
void aff_rendu(M_emprunt *p,int n);
void aff_Adr(M_emprunt *p,M_emprunt *q) ;
int cot_emprunt (M_emprunt *p) ;
int n_emprunteur(M_emprunt *p) ;
char * date_emprunt(M_emprunt *p) ;
void  date_pretour(M_emprunt *p,int *j,int *m,int *a) ;
char * date_effectiv(M_emprunt *p);
int rendu (M_emprunt *p) ;
M_emprunt * suit (M_emprunt *p);

//LES FONCTION DE TP1 ::::::
void inscription(M_emprunteur **tete);
void initialiser (M_emprunteur **tete) ;
void Affiche (M_emprunteur* *tete) ;
void Init_fich_sec(struct list_livre* *tete,M_emprunt *tet) ;
void lire_fich1(struct list_livre* *tete) ;
void recotr(struct list_livre* tete) ;
void lire_fich2(struct list_livre* *tete) ;
void affichi(struct list_livre* *tete) ;
void restitution (struct list_livre *tete1,M_emprunt *tete2 , M_emprunteur *tete3);
int cherche_ord(M_emprunteur *tete,char nom[15],char prenom[15]);//chercher le nemuro d'ordre d'un emprunteur d'apres le nom et le prenom
void date_ent (int *jour ,int *mois, int *anne ,char chain[10]);
void date_limite(int *jour,int *mois,int *anne,char chain[10]);
void lire_fich_emprunt (M_emprunt **tete);
void Affiche_emp (M_emprunt* *tete) ;
void affich_list_tri(struct list_livre* tete,M_emprunt* tete1) ;
void emprunter(struct list_livre *tete,M_emprunteur *tet,M_emprunt* *te);
void enregistrer (struct list_livre *tete,M_emprunteur *tet,M_emprunt *te) ;
