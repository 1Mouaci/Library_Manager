#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <stdio.h>
#include <windows.h>
#include "Bib_LLC_BIBLIO.h"
#include "conio.h"
#include"graphisme.h"
#define MAX 1000
char chain[MAX];

struct list_livre *allouer()
{
    return((struct list_livre *)malloc(sizeof(struct list_livre))) ;
}

void aff_adr(struct list_livre *p,struct list_livre *q)
{
  p->next=q ;
}

int valeur_cote(struct list_livre* tete )
{
    return(tete->livre.cote) ;
}

char valeur_titre(struct list_livre* tete)
{
    return(tete->livre.titre) ;
}
char valeur_auteur(struct list_livre* tete)
{
    return(tete->livre.auteur) ;
}

int valeur_date_edit(struct list_livre* tete)
{
    return(tete->livre.date_edit) ;
}

char valeur_editeur(struct list_livre* tete)
{
    return(tete->livre.editeur) ;
}

char valeur_resume(struct list_livre* tete)
{
    return(tete->livre.resume) ;
}

void aff_cote (struct list_livre *lv ,int cot )
{
    lv->livre.cote=cot ;
}

void aff_titre(struct list_livre *lv, char titr[100])
{
   strcpy(lv->livre.titre,titr) ;
}

void aff_auteur(struct list_livre *lv ,char oteur[30])
{
    strcpy(lv->livre.auteur,oteur) ;
}

void aff_date_edit(struct list_livre *lv,int date)
{
    lv->livre.date_edit=date ;
}

void aff_editeur(struct list_livre *lv,char editr[50])
{
    strcpy(lv->livre.editeur,editr) ;
}

void aff_mot_cle(struct list_livre *p, char tmp[10][50],int i )
{
    int j ;
    for (j=0 ;j<=i ;j++) {strcpy(p->livre.t[j],tmp[j]);}
}
void aff_resume(struct list_livre *lv,char resum [400])
{
    strcpy(lv->livre.resume,resum) ;
}

void Init_fich_sec(struct list_livre* *tete,M_emprunt *tet)
    {
        struct list_livre *z ;
        M_emprunt *n ;
        int i ;

        z = *tete;
        while(z!= NULL)
        {
            z->livre.disponible=1 ;
            n= tet ;
            while(n!= NULL)
            {
                if(z->livre.cote == n->cot_livre ) z->livre.disponible = n->rendu ;
                n = n->suit ;
            }
            z = z->next ;
        }


        z=*tete ;
        FILE*fich=fopen("liste des livres2.txt","w") ;

        while (z !=NULL)
        {
         fprintf(fich,"%d %s %s %s %d (",z->livre.cote,z->livre.titre,z->livre.auteur,z->livre.editeur,z->livre.date_edit);
        for (i=0 ; i<z->livre.help ; i++)
       {
           fprintf(fich,"%c",z->livre.t[i]) ;
       }
        fprintf(fich,") #%s# %d\n",z->livre.resume,z->livre.disponible) ;
            z=z->next ;

        }
        fclose(fich) ;

    }

void convert_chain(char bil[10],int t[2])
       {
       int dat,j ,i=0,p=10 ,res=0,mont,resm=0 ,last, rey=0,k;
        for (i=0 ;i<2 ;i++)
        {
        dat=(int) bil[i]-48 ;
        res=res+dat*p ;
        p=p/10 ;
        }
       p=10 ;
       for (j=3 ; j<5 ; j++)
       {
           mont=(int) bil[j]-48 ;
           resm= resm +p*mont ;
           p=p/10 ;
       }
       p=1000 ;
       for (k=6 ; k<10 ; k++)
       {
           last=(int) bil[k]-48 ;
           rey=rey+p*last ;
           p/=10 ;
       }
   t[0]=res ;
   t[1]=resm ;
   t[2]=rey ;
       }

void lire_fich1(struct list_livre* *tete)
{
    struct list_livre *p,*q ;
    int i,k=0,j  ;
    char chain[1000] ;
    char temp [100];
    char c ;
    char res[400] ;

   FILE* fil=fopen("liste des livres1.txt","r") ;
   if (!fich_vide(fil))
   {
    fil = fopen("liste des livres1.txt","r");

    do
    {
    p=allouer() ;
    fscanf(fil,"%d %s %s %s %d",&p->livre.cote,&p->livre.titre,&p->livre.auteur,&p->livre.editeur,&p->livre.date_edit);

    while ((c=fgetc(fil))!='('&& c!=EOF) {}
          int open=ftell(fil) ;

      fseek(fil,open,SEEK_SET) ;
      j=0 ;
        while ((c=fgetc(fil))!= ')'&& c!=EOF)
        {
         temp[j]=c ;
         j++ ;
        }
        p->livre.help=j ;
        for (i=0 ; i<p->livre.help ; i++)  p->livre.t[i]=temp[i] ;


      i=0 ;
     while ((c=fgetc(fil))!='#' && c!=EOF) {}
     while ((c=fgetc(fil))!= '#'&& c!=EOF)
     {
         res[i++]=c ;
     }

     res[i]= '\0';
     aff_resume(p,res) ;

    if (*tete==NULL) *tete=p ;
    else aff_adr(q,p) ;
    q=p ;
    }
     while (fgets(chain,1000,fil)!=NULL) ;
     aff_adr(p,NULL) ;
   }
     fclose(fil) ;

}

void recotr(struct list_livre* tete)
 {
     struct list_livre *z ;
     char mot[30] ;
     int test=0,i ;
     printf("Entrer Le nom de L'auteur : \n") ;
     scanf("%s",mot) ;
     printf("\nLes r\sultats :\n ");
      z=tete ;
      while ( z != NULL && !test)
     {
       if ((strstr(z->livre.auteur,mot)) && (strlen(mot)==strlen(z->livre.auteur)))
         {

         printf("Le livre :%s\n",z->livre.titre) ;
         printf("-Le cote :%d \n-L'auteur :%s \n-L'editeur :%s -La date d'idition :%d\n",z->livre.cote,z->livre.auteur,z->livre.editeur,z->livre.date_edit);
         printf("Les mots cl\202s :");
         for(i=0 ; i< z->livre.help ; i++) printf("%c",z->livre.t[i]) ;
         printf("\nLe r\202sum\202 :%s\n",z->livre.resume) ;
         printf("L'\202tat de livre :");
         if (z->livre.disponible ==1)
         {
             textbackground(GREEN);
             printf("Disponible\n") ;
         }
         else
         {
             textbackground(RED);
             printf("Non disponible\n");
         }
        textbackground(BLACK);
         printf("\n") ;
         test++ ;
         }
       z=z->next ;
     }
     if (test==0) printf("Nous n'avons aucun livre pour l'auteur %s\n",mot) ;
 }

void lire_fich2(struct list_livre* *tete)
{
    struct list_livre *p,*q ,*r;
    int i,j ,k=0 ;
    char chain[1000] ;
    char temp[100];
    char c ;
    char res[400] ;

   FILE* fil=fopen("liste des livres2.txt","r") ;

   if (!fich_vide(fil))
   {
    fil = fopen("liste des livres2.txt","r");
    do
    {
    p=allouer() ;
    fscanf(fil,"%d %s %s %s %d ",&p->livre.cote,p->livre.titre,p->livre.auteur,p->livre.editeur,&p->livre.date_edit);

     while ((c=fgetc(fil))!='('&& c!=EOF) {}
          int open=ftell(fil) ;

      fseek(fil,open,SEEK_SET) ;
      j=0 ;
        while ((c=fgetc(fil))!= ')'&& c!=EOF)
        {
         temp[j]=c ;
         j++ ;
        }
        p->livre.help=j ;
        for (i=0 ; i<p->livre.help ; i++)  p->livre.t[i]=temp[i] ;
     i=0 ;
     while ((c=fgetc(fil))!='#' && c!=EOF) {}
     while ((c=fgetc(fil))!= '#'&& c!=EOF)
     {
         res[i++]=c ;
     }

     res[i]='\0';
     aff_resume(p,res) ;
     fscanf(fil,"%d",&p->livre.disponible) ;
    if (*tete==NULL) *tete=p ;
    else aff_adr(q,p) ;
    r=q ;
    q=p ;
    }
     while (fgets(chain,1000,fil)!=NULL) ;
     aff_adr(r,NULL) ;
   }
     fclose(fil) ;
    }


 void affichi(struct list_livre* *tete)
    {
        struct list_livre *z ;
        z=*tete ;
        int i=0 ,w=0 ;
        while (z !=NULL)
        {

        printf("%d %s %s %s %d ",z->livre.cote,z->livre.titre,z->livre.auteur,z->livre.editeur,z->livre.date_edit);


       for (i=0 ; i<z->livre.help ; i++)
       {
           printf("%c",z->livre.t[i]) ;
       }
        printf(" %s %d\n",z->livre.resume,z->livre.disponible) ;
            z=z->next ;

        }
    }

/*MACHINE ABSTRAITE POUR LEs EMPRUNTS  */
void Alo_emprunt (M_emprunt **p)
{
    *p = ((M_emprunt *)malloc(sizeof(M_emprunt)));
}

void aff_co_livre(M_emprunt *p,int n)
{
    p->cot_livre = n ;
}

void aff_n_emp(M_emprunt *p,int n)
{
    p->n_emp = n ;
}

void aff_demprunt(M_emprunt *p,char n[])
{
    strcpy(p->dat_emprunt,n);
}

void aff_preretour(M_emprunt *p,int j,int m,int a )
{
    p->d_limite.jour =j ;
    p->d_limite.mois = m;
    p->d_limite.anne =a ;
}

void aff_rendu(M_emprunt *p,int n)
{
    p->rendu = n ;
}

void aff_Ar(M_emprunt *p,M_emprunt *q)
{
    p->suit = q ;
}

int cot_emprunt (M_emprunt *p)
{
    return p->cot_livre ;
}

int n_emprunteur(M_emprunt *p)
{
    return p->n_emp ;
}

char * date_emprunt(M_emprunt *p)
{
    return p->dat_emprunt ;
}

void  date_pretour(M_emprunt *p,int *j,int *m,int *a)
{
     *j = p->d_limite.jour;
     *m = p->d_limite.mois ;
     *a = p->d_limite.anne ;
}

int rendu (M_emprunt *p)
{
    return p->rendu ;
}

M_emprunt * suit (M_emprunt *p)
{
    return p->suit;
}

/*:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::*/

/*EMPRUNT */
int cherche_ord(M_emprunteur *tete,char n[15],char p[15])
{
    M_emprunteur* q = tete ;
    int say = 0 ;/*la perssone est trouvee dans la liste d'emprunteur */

    while ((q != NULL)&&(!say))
    {
        if(strcmp(nom(q),n)==0 && strcmp(prenom(q),p)==0)
        {
            say = 1 ;
        }
        else  q=suiv(q);
    }

    if (q!= NULL) return n_ordre(q);
    else  return 0 ;//si l'emprunteur n'est pas encore inscrit
}

int cherche_cot(struct list_livre *tete,char n[100])
{
    struct list_livre * q = tete ;
    int say = 0 ;/*la perssone est trouvee dans la liste d'emprunteur */

    while ((q != NULL)&&(!say))
    {

        if(strcmp(n,q->livre.titre)==0 )
        {
            say = 1 ;
        }
        else  q=q->next;
    }
    if (q!= NULL) return q->livre.cote;
    else  return 0 ;//si l'emprunteur n'est pas encore inscrit
}

void lire_fich_emprunt (M_emprunt* *tete)
{
    M_emprunt *p,*q,*r ;//pointeur sur la structure ::::::::::::::
    FILE *fich = fopen("Liste des emprunts1.txt","r");// pointeur sur le fichier ::::::::::
    char chain[MAX];

    if (!fich_vide(fich))
   {
    fich = fopen("liste des emprunts1.txt","r");
    do
    {
        Alo_emprunt(&p) ;//pointeur courant
        fscanf(fich,"%d %d %s",&p->cot_livre,&p->n_emp,p->dat_emprunt);
        date_limite(&p->d_limite.jour,&p->d_limite.mois,&p->d_limite.anne,p->dat_emprunt);
        if (*tete==NULL) *tete=p ;
        else q->suit=p ;
        r = q ;//precedent de precedent
        q = p ;//precedent du pointeur courant
    }
    while (fgets(chain,MAX,fich)!=NULL);

     q->suit=NULL ;
    }
     fclose(fich) ;
}
void init_emprunt (M_emprunt* *tete)
{
    M_emprunt *p,*q ;
    int cot,nem,test;

    p=*tete ;

    while(p!=NULL)
    {
        test =1;
        nem = p->n_emp;
        cot = p->cot_livre;
        p->rendu = 0;
        q = p->suit ;
        while(q!=NULL && test)
        {

            if(q->n_emp == nem ||  q->cot_livre == cot)
            {
                p->rendu=1;
                test = 0;
            }
            q = q->suit ;
        }
        p= p->suit;
    }

    FILE*fich=fopen("liste des emprunts2.txt","w") ;
    p = *tete ;
    while (p !=NULL)
    {
   fprintf(fich,"%d %d %s %d %d %d %d\n",p->cot_livre,p->n_emp,p->dat_emprunt,p->d_limite.jour,p->d_limite.mois,p->d_limite.anne,p->rendu) ;
   p=p->suit ;
    }
  fclose(fich) ;

}

void Affiche_emp (M_emprunt* *tete)
{
    M_emprunt *p;
    p =*tete ;
    while (p != NULL)
    {

        printf("%d %d %s %d %d %d\n",p->cot_livre,p->n_emp,p->dat_emprunt,p->d_limite.jour,p->d_limite.mois,p->d_limite.anne) ;
        p= p->suit;
    }
}

void affich_list_tri(struct list_livre *tete,M_emprunt *tete1)
{
struct list_livre *p ;
    M_emprunt *q ;
    int i,max,ind,k,j=0 ,cpt;
    struct tri_livres t[100] ;
   p=tete ;
    while (p !=NULL)
     {
    cpt=0 ;
    q=tete1 ;

    while (q !=NULL)
{
   if (p->livre.cote == q->cot_livre )  cpt ++ ;
   q=q->suit ;
}
    t[j].occurence = cpt ;
    strcpy(t[j].titre,p->livre.titre);
    j++ ;
    p=p->next ;
}

   printf("Voila la liste des livre triee selon le nombre d'emprunt :\n\n") ;
   for (k=0 ; k<j ; k++)
    {
    max=t[0].occurence ;
    ind=0 ;
    for (i=1 ; i<j ; i++)
    {
        if (max < t[i].occurence)
        {
            ind=i ;
            max=t[i].occurence ;
        }
    }
    if (max==0) printf(" Aucune emprunt pour le livre sous le titre : %s\n",t[ind].titre ) ;
   else  printf(" Le livre sous le titre : %s est emprunte ' %d  ' fois\n",t[ind].titre,max) ;
   printf("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");
    t[ind].occurence=-1 ;
    }

}
void lire_fich_emprunt1 (M_emprunt* *tete)
{
    M_emprunt *p,*q,*r ;//pointeur sur la structure ::::::::::::::
    FILE *fich = fopen("Liste des emprunts2.txt","r");// pointeur sur le fichier ::::::::::
    char chain[MAX];

    if (!fich_vide(fich))
   {
    fich = fopen("liste des emprunts2.txt","r");
    do
    {
        Alo_emprunt(&p) ;//pointeur courant
        fscanf(fich,"%d %d %s %d %d %d %d",&p->cot_livre,&p->n_emp,p->dat_emprunt,&p->d_limite.jour,&p->d_limite.mois,&p->d_limite.anne,&p->rendu);
        if (*tete==NULL) *tete=p ;
        else q->suit=p ;
        r = q ;//precedent de precedent
        q = p ;//precedent du pointeur courant
    }
    while (fgets(chain,MAX,fich)!=NULL);
    r->suit=NULL ;
   }
    fclose(fich) ;
}

void Affiche_emp1 (M_emprunt* *tete)
{
    M_emprunt *p;
    p =*tete ;
    while (p != NULL)
    {

        printf("%d %d %s %d %d %d %d\n",p->cot_livre,p->n_emp,p->dat_emprunt,p->d_limite.jour,p->d_limite.mois,p->d_limite.anne,p->rendu) ;
        p= p->suit;
    }
}

void eclat_list (M_emprunt *tete,M_emprunt* *t1,M_emprunt* *t2)
{
    M_emprunt *p,*q,*r,*s,*d ;
   *t1=NULL ;
   *t2=NULL ;
   if(tete !=NULL)
   {
    p=tete ;
     while (p!=NULL)
     {
      if (p->rendu == 0)
      {
          Alo_emprunt(&s) ;
          if (*t1==NULL) *t1=s;
          else d->suit=s ;
          s->cot_livre =p->cot_livre ;
          s->n_emp =p->n_emp ;
          strcpy(s->dat_emprunt,p->dat_emprunt);
          s->d_limite.jour =p->d_limite.jour ;
          s->d_limite.mois =p->d_limite.mois ;
          s->d_limite.anne =p->d_limite.anne ;
          d=s ;
      }
      else
      {
          Alo_emprunt(&q) ;
          if (*t2==NULL) *t2=q;
          else r->suit=q ;
          q->cot_livre =p->cot_livre ;
          q->n_emp =p->n_emp ;
          strcpy(q->dat_emprunt,p->dat_emprunt);
          q->d_limite.jour =p->d_limite.jour ;
          q->d_limite.mois =p->d_limite.mois ;
          q->d_limite.anne =p->d_limite.anne ;
          r=q ;
      }
      p=p->suit ;
    }
    s->suit=NULL ;
    q->suit=NULL ;
    FILE*fich=fopen("Eclatement de liste en 2.txt","w") ;
     d =*t1 ;
     fprintf(fich," La Liste des Emprunts en cours :\n") ;
    while (d != NULL)
    {

        fprintf(fich," %d %d %s %d %d %d\n",d->cot_livre,d->n_emp,d->dat_emprunt,d->d_limite.jour,d->d_limite.mois,d->d_limite.anne) ;
        d= d->suit;
    }
    fprintf(fich,"\n") ;
    d=*t2 ;
    fprintf(fich," La Liste des Emprunts non en cours :\n") ;
    while (d != NULL)
    {

        fprintf(fich," %d %d %s %d %d %d\n",d->cot_livre,d->n_emp,d->dat_emprunt,d->d_limite.jour,d->d_limite.mois,d->d_limite.anne) ;
        d= d->suit;
    }
    printf(" Enregistrement R\202ussi \n") ;
    printf(" \nVeuillez V\202rifier le fichier : Eclatement\n");


    fclose(fich) ;
    }
    else printf("aucun emprunt a \202t\202 fait !\n");
}

void affich_nom (M_emprunteur *tete,int n_emp)
{
    M_emprunteur *p ;
    p =tete ;
    while(p!=NULL && n_ordre(p)!=n_emp)
    {
        p = suiv(p);
    }
    printf("%s  %s",nom(p),prenom(p));
}


void affich_livre (struct list_livre *tete,int cot)
{
    struct list_livre *p ;
    p =tete ;
    while(p!=NULL && p->livre.cote!=cot)
    {
        p = p->next ;
    }
    printf("Le titre :%s --emprunt\202 par ",p->livre.titre);
}

void affich_indisponible (struct list_livre *tete0 ,M_emprunteur *tete1,M_emprunt *tete2)
{
    int j,m,a ;
    M_emprunt *q ;

    q = tete2 ;

    while(q!= NULL)
    {
        if (!rendu(q))
        {
        date_pretour(q,&j,&m,&a);
        affich_livre(tete0,q->cot_livre);
        affich_nom(tete1,q->n_emp);
        printf(" sa retoure est pr\202vue pour le %d/%d/%d \n",j,m,a);
        printf("------------------------------------------------------------------------------------------\n");

        }
        q =q->suit;
    }
}

int difdat(int j1,int m1,int a1,char dat2[10])
{
    int i ;
    int j2,m2,a2 ;
    int cal[12]={31,28,31,30,31,30,31,31,30,31,30,31,0};
    int dif1 = 0;int dif2=0 ;
    int cum1 =0 ;int cum2 =0 ;

    date_ent(&j2,&m2,&a2,dat2);

    for (i=0;i<m1 -1;i++)
    {
        cum1 = cum1 +cal[i];
    }

    for (i=0;i<m2-1;i++)
    {
        cum2 = cum2 +cal[i];
    }

    dif1 = a1*365 + cum1 + j1 ;
    dif2 = a2*365 +cum2 +j2 ;

    return (dif2-dif1);
}




int pina (M_emprunt *tete ,M_emprunteur *q)
{
    M_emprunt *p;
    int pin,j,m,a,jj,mm,aa ;
    char date[10] ;
    time_t now = time (NULL);/* lire l'heure courante */
    struct tm tm_now = *localtime (&now);/* la convertir en heure locale */
    strftime (date, sizeof "JJ/MM/AAAA", "%d/%m/%Y", &tm_now);

    p = tete;

    if(q->pinalite ==0)
    {
    while(p!=NULL && (p->n_emp!=q->n_ord || p->rendu))
    {
        p = p->suit;
    }

    if(p!=NULL)
    {
        date_pretour(p,&j,&m,&a);
        pin = difdat(j,m,a,date);
    }

    }
    else
    {
        while(p!=NULL && (p->n_emp != q->n_ord || !p->rendu))
        {
            p=p->suit ;
        }
        if(p!=NULL)
        {
            date_pretour(p,&j,&m,&a);
            ajout_dat(&jj,&mm,&aa,j,m,a,q->pinalite);
            pin = difdat(jj,mm,aa,date);
        }
    }
    if (pin < 0 || p==NULL) pin = 0;
    return pin ;
}

int emprunt_emprunteur (M_emprunt *tete1,int n_ordre)
{//calculer le nombre d'emprunt par emprunteur a partir de son numero d'ordre :::::
    M_emprunteur *p ;M_emprunt *q ;int nb_emprunt=0 ;

    q = tete1 ;
    while (q != NULL)
    {
        if (n_ordre == n_emprunteur(q))
        {
            nb_emprunt++ ;
        }
        q = suit(q);
    }
    return nb_emprunt ;
}


void emprunt_emprunteurs (M_emprunt *tete1,M_emprunteur*tete2)
{//afficher le nombre d'emprunt pour tous les emprunteurs
    M_emprunteur *p ;M_emprunt *q ;int nb_emprunt=0 ;
    int cpt;

        p = tete2 ;
        while(p != NULL)
        {
            cpt = emprunt_emprunteur(tete1,n_ordre(p));
            if (cpt==0) printf("L'emprunteur  * %10s * * %10s * n'a aucune emprunt \n",nom(p),prenom(p)) ;
            else printf("L'emprunteur  * %10s * * %10s * a emprunt\202 : %d fois\n",nom(p),prenom(p),cpt);
            p= suiv(p) ;
            printf("-----------------------------------------------------------------------------------------\n");
        }

}


void date_limite(int *jour,int *mois,int *anne,char chain[10])
{//donner la date limite pour chaque emprunt
    int j,m,a ;
    int cal[12] ={31,28,31,30,31,30,31,31,30,31,30,31,0};
    date_ent(&j,&m,&a,chain);
    *jour = j ;
    *mois = m ;
    *anne = a ;
    *jour = *jour +28 ;
    if (*jour > cal[*mois-1])
    {
        *jour = *jour%(cal[*mois-1]);
        *mois = *mois +1 ;
        if(*mois>12)
        {
            *mois = 1 ;
            *anne = *anne + 1 ;
        }
    }
}

void date_ent (int *jour ,int *mois, int *anne ,char chain[10] )
{//convertir une date d'une chaine aux entiers:::
    int i,p=10 ,dat,mont ,last;
    //char chain[10];
    //time_t now = time (NULL);/* lire l'heure courante */
    //struct tm tm_now = *localtime (&now);/* la convertir en heure locale */

    //strftime (chain, sizeof "JJ/MM/AAAA", "%d/%m/%Y", &tm_now);/*s_now contient la date de l'inscription */
    *jour=0 ;
    *mois=0 ;
    *anne=0 ;

    for (i=0 ;i<2 ;i++)
    {
        dat=(int) chain[i]-48 ;
        *jour=*jour+dat*p ;
        p=p/10 ;
    }
    p=10 ;
    for (i=3 ; i<5 ; i++)
    {
        mont=(int) chain[i]-48 ;
        *mois= *mois +p*mont ;
        p=p/10 ;
    }
    p=1000 ;
    for (i=6 ; i<10 ; i++)
    {
        last=(int) chain[i]-48 ;
        *anne =*anne+p*last ;
        p=p/10 ;
    }
}

int fich_vide(FILE *file)
{//rend 0 si le fichier est vide :::::::
    int cpt =0 ;
    char chain[MAX];

     while(fgets(chain,MAX,file) != NULL)
    {
        cpt++;
    }
    return !(cpt>1) ;
}

void init_fich (M_emprunteur **tete,M_emprunt *tet)
{//lire le fichier donn� et ecrire dans un autre fichier::::::
    M_emprunteur *p,*q,*r,*s;//pointeur sur la structure ::::::::::::::
    M_emprunt *y ;
    FILE *fich = fopen("liste des emprunteurs1.txt","r");// pointeur sur le fichier ::::::::::
    FILE *fil = fopen("liste des emprunteurs2.txt","w");
    char chain[MAX] ;
    int cot,nem ;

   *tete=NULL ;


   if (!fich_vide(fich))
   {
    fich = fopen("liste des emprunteurs1.txt","r");
    do
    {
        Alo_emprunteur(&p) ;
        p->pinalite=0 ;
        fscanf(fich,"%s %s %s %s %d",p->nom,p->prenom,p->adress,p->n_tep,&p->n_ord);
        if (*tete==NULL) *tete=p ;
        else q->suiv=p ;
        r = q ;
        q=p ;

    }
    while (fgets(chain,MAX,fich)!=NULL);

    r->suiv=NULL;
    fclose(fich) ;

    p = *tete ;
    while(p != NULL)
    {
        p->prend =0;
        y = tet;
        while(y!=NULL)
        {
            if(p->n_ord==y->n_emp) p->prend=!y->rendu ;
            y = y->suit;
        }
        p=p->suiv ;
    }
   }


    s= *tete ;

    while(s!=NULL)
    {
        fprintf(fil,"%s %s %s %s %d %d %d\n",nom(s),prenom(s),s->adress,telephon(s),n_ordre(s),s->prend,0);
        s=s->suiv;
    }

    fclose(fil);
}


void initialiser(M_emprunteur **tete)
{//initialiser la llc par le fichier secondaire :::::::
    M_emprunteur *p,*q,*r ;
    FILE *fich = fopen("liste des emprunteurs2.txt","r");//pointeur sur un fichier contient la date de premier inscription ainsi que l'etet;si il prend un livre en cours ou pas ::::::
    char chain[MAX];

        *tete = NULL ;
   if (!fich_vide(fich))
   {
    fich = fopen("liste des emprunteurs2.txt","r");
    do
    {
        Alo_emprunteur(&p);
        fscanf(fich,"%s %s %s %s %d %d %d",p->nom,p->prenom,&p->adress,&p->n_tep,&p->n_ord,&p->prend,&p->pinalite);
        if(*tete== NULL) *tete = p ;
        else  Aff_adr(q,p) ;
        r=q ;
        q = p ;//precedent du pointeur courant

    }while ( fgets(chain,MAX,fich)!=NULL);
    Aff_adr(r,NULL);
   }

}

// *** Emprunteur ***
void Alo_emprunteur(M_emprunteur **p)
{
    *p=((M_emprunteur*)malloc(sizeof(M_emprunteur)));
}

void Aff_nom(M_emprunteur *p,char n[])
{
    strcpy(p->nom,n) ;
}

void Aff_pre(M_emprunteur *p,char n[])
{
    strcpy(p->prenom,n);
}

void Aff_tep(M_emprunteur *p,char n[])
{
    strcpy(p->n_tep,n) ;
}

void Aff_adress (M_emprunteur *p,char n[])
{
    strcpy(p->adress,n) ;
}

void Aff_ord(M_emprunteur *p,int n)
{
    p->n_ord=n;
}

void Aff_ins (M_emprunteur *p,char n[])
{
    strcpy(p->pr_ins,n);
}


void Aff_adr(M_emprunteur *P, M_emprunteur *Q)
 {
       P->suiv =Q;
 }

void aff_prend(M_emprunteur *p,int n)
{
    p->prend = n ;
}

char* nom(M_emprunteur *p)
{
    return p->nom ;
}

char* prenom (M_emprunteur *p)
{
    return p->prenom ;
}

char* telephon(M_emprunteur *p)
{
    return p->n_tep ;
}

int n_ordre(M_emprunteur *p)
{
    return p->n_ord ;
}

char* pre_ins(M_emprunteur *p)
{
    return p->pr_ins ;
}

int prend (M_emprunteur *p)
{
    return p->prend ;
}

M_emprunteur* suiv(M_emprunteur *p)
{
    return p->suiv ;
}

void libere(M_emprunteur *p)
{
    free(p);
}

void restitution (struct list_livre *tete1,M_emprunt *tete2 , M_emprunteur *tete3)
{
        struct list_livre *p; M_emprunt *q ;M_emprunteur *r ;
        int nem,ct,ord ;
        char n[100] ;
        char nom[15];
        char prn[15];

        p = tete1 ;
        q = tete2 ;
        r = tete3 ;
        printf("Donnez le nom du livre\n") ;
        scanf("%s",n) ;
        ct=cherche_cot(tete1,n) ;
        printf("Donner votre nom \n");
        scanf("%s",nom);
        printf("Donner votre prenom\n");
        scanf("%s",prn);
        ord =cherche_ord(tete3,nom,prn);
        if(ord && ct)
        {
        while(q != NULL && (q->cot_livre!=ct  || (q->rendu)))
        {
            q = q->suit;
        }
        if(q!=NULL && q->n_emp==ord)
        {
            nem = q->n_emp ;

        while(p!=NULL && p->livre.cote != ct)
        {

            p = p->next;
        }
        if (p!=NULL) p->livre.disponible = 1 ;

        while(r!= NULL && (r->n_ord != nem))
        {
            r = r->suiv ;
        }
        if (r != NULL)
        {

            r->pinalite = r->pinalite + pina(tete2,r);
            q->rendu = 1 ;
            r->prend = 0 ;
            printf("ristitution reussit \n");
        }
        }
        if (q == NULL) printf("Le livre '%s' n'a pas \202t\202 emprunt\202 \n",n);
        else if (nem != ord) printf("'%s' '%s',Vous n'avez pas emprunt\202 le livre '%s'\n",nom,prn,n);
        }
        if (!ct) printf("Le livre '%s' n'existe pas \n",n) ;
        if (!ord) printf("L'empruunteur '%s' '%s' n'existe pas il faut d'abord inscrit \n",nom,prn);
}


void Affiche (M_emprunteur* *tete)
{//afficher la liste d'emprunteur ::::::::
    M_emprunteur *p;

    p =*tete ;
    while (p!= NULL)
    {
        printf("%s %s %s %s %d %d %d\n",nom(p),prenom(p),p->adress,telephon(p),n_ordre(p),prend(p),p->pinalite);
        p= p->suiv;
    }
}

void affich_pinailite(M_emprunteur *tete1,M_emprunt *tete2)
{
    M_emprunteur *p;
    M_emprunt *q ;
    int pin ;

    p = tete1 ;
    while(p != NULL)
    {
        if( p->pinalite==0) pin = pina(tete2,p)  ;
        else pin = p->pinalite - pina(tete2,p) ;
        printf("'%s' '%s' :",p->nom,p->prenom);
        if(pin==0)
        {
            textcolor(LIGHTGREEN);
            printf(" %d : Non pinalis\202 \n\n",pin);
        }
        else
        {
           textcolor(LIGHTRED);
           printf(" %d : pinalis\202 \n\n",pin);
        }
        textcolor(LIGHTCYAN);
        p = p->suiv ;
    }
}

void cherch_mot(struct list_livre *tete)
{// cherher un mot dans un tableau de chaine de caracteres
    char mot[100] ;
    int test=0,i ;
    struct list_livre *z ;
    printf("Donnez le mot cl\202 : \n") ;
    scanf("%s",mot) ;
    z=tete ;
    printf("\nLes r\202sultats :\n\n");
    while (z!=NULL)
    {
         if ((strstr(z->livre.t,mot)))
         {
             printf("Le livre :%s \n",z->livre.titre);
         printf("-Le cote :%d \n-L'auteur :%s \n-L'editeur :%s -La date d'idition :%d\n",z->livre.cote,z->livre.auteur,z->livre.editeur,z->livre.date_edit);
         printf("Les mot cles :");
         for(i=0 ; i< z->livre.help ; i++) printf("%c",z->livre.t[i]) ;
         printf("\nle resum\202 :%s\n",z->livre.resume) ;
         printf("L'\202tat de livre :");
         if (z->livre.disponible ==1)
         {
             textbackground(GREEN);
             printf("Disponible\n") ;
         }
         else
         {
             textbackground(RED) ;
             printf("Non disponible\n");

         }
         textbackground(BLACK);
         printf("\n") ;
         test++ ;
         }
         z=z->next ;
    }
   if (test==0) printf("Aucun de nos livres contient ce mot \n") ;
}

void recherch_par_motcles(struct list_livre *tete)
{
    int test=1 ;
    char repeat[2] ;
    while (test)
    {
    cherch_mot(tete) ;
    printf("Voulez vous Introduire un autre mot ? \n") ;
    printf("Repondez Par  oui | non\n") ;
    scanf("%s",repeat) ;
    if (strstr(repeat,"non")) test=0 ;
    else test=1 ;
     }
}

void inscription(M_emprunteur **tete)
{//nouveau personne qui veut inscrire on v l'ajouter au debut de la liste et ajouter dans la ligne suivante de fichier :::::::::

    int n,nem,test =1 ;
    M_emprunteur *p,*t;//pointeur sur la structure ::::::::::::::
    FILE* fich = fopen("liste des emprunteurs1.txt","a+");/*ouvrir le fichier fich_emprunteur */
    FILE* fil = fopen("liste des emprunteurs2.txt","a+");
    time_t now = time (NULL);/* lire l'heure courante */
    struct tm tm_now = *localtime (&now);/* la convertir en heure locale */

    Alo_emprunteur(&p);

    strftime (chain, sizeof "JJ/MM/AAAA", "%d/%m/%Y", &tm_now);/*s_now contient la date de l'inscription */

    Aff_ins(p,chain) ;
    Aff_ord(p,0);
    p->pinalite=0 ;  //pour ce qui concerne le numero d'ordre je vais donner au nouveau nobre de lignes +1

    aff_prend(p,0);
    printf("Entrer Votre Nom:\n");
    scanf("%s",&chain);
    Aff_nom(p,chain);
    printf("Entrer Votre Pr\202nom:\n");
    scanf("%s",&chain);
    Aff_pre(p,chain);
    printf("Entrer Votre Num\202ro de t\202lephone :\n");
    scanf("%s",&chain);
    Aff_tep(p,chain);
    printf("Entrer Votre Adresse :\n");
    scanf("%s",&chain);
    Aff_adress(p,chain);

    nem = cherche_ord(*tete,p->nom,p->prenom);
     Aff_adr(p,*tete);
    *tete = p ;
    if(!nem)
    {
        Aff_ord(p,1);
         while ( fgets(chain,MAX,fil)!=NULL)
        {
            Aff_ord(p,n_ordre(p)+1);
        }
        fprintf(fich,"%s %s %s %s %d\n",nom(p),prenom(p),p->adress,telephon(p),n_ordre(p));
        fprintf(fil,"%s %s %s %s %d %d %d\n",nom(p),prenom(p),p->adress,telephon(p),n_ordre(p),prend(p),p->pinalite);
        printf("Votre Inscription est r\202ussite") ;

    }
    else printf("Vous etes d\202ja inscrit !\n");
    fclose(fich);//
    fclose(fil);
}

void emprunter(struct list_livre *tete,M_emprunteur *tet,M_emprunt* *te)
{
    FILE *fich=fopen("liste des emprunts1.txt","a+");
    FILE *fil=fopen("liste des emprunts2.txt","a+");

    struct list_livre *p= tete  ;
    M_emprunteur *q =tet;
    M_emprunt *r,*s  ;
    int cot,ord,j,m,a ;
    char nom[15],liv[100],prnom[15] ;

    char chain[MAX];
    time_t now = time (NULL);/* lire l'heure courante */
    struct tm tm_now = *localtime (&now);/* la convertir en heure locale */

    strftime (chain, sizeof "JJ/MM/AAAA", "%d/%m/%Y", &tm_now);/*s_now contient la date de l'inscription */

    printf("Entrer Votre Nom : \n") ;
    scanf("%s",nom) ;
    printf("Entrer Votre Pr\202nom : \n") ;
    scanf("%s",prnom) ;
    printf("Entrer Le Nom Du Livre : \n") ;
    scanf("%s",liv) ;

    cot=cherche_cot(tete,liv) ;
    ord=cherche_ord(tet,nom,prnom) ;

    if(ord && cot)
    {
        while(p != NULL && p->livre.cote!=cot)
        {
            p = p->next ;
        }

        while(q!=NULL && n_ordre(q)!=ord)
        {
            q = suiv(q) ;
        }

        if(!q->pinalite)
        {
            if(p!=NULL && q !=NULL)
            {
                if(p->livre.disponible && !prend(q))
                {

                    p->livre.disponible=0 ;
                    aff_prend(q,1) ;
                    Alo_emprunt(&r) ;
                    r->suit=*te ;
                    *te=r ;
                    date_limite(&j,&m,&a,chain) ;
                    r->rendu = 0 ;
                    r->cot_livre =cot ;
                    r->n_emp = ord ;
                    strcpy(r->dat_emprunt,chain);
                    aff_preretour(r,j,m,a);
                    fprintf(fil,"%d %d %s %d %d %d %d\n",cot,ord,chain,j,m,a,0);
                    fprintf(fich,"%d %d %s %d %d %d\n",cot,ord,chain,j,m,a);
                }
                else
                {
                    if(!p->livre.disponible) printf("Le livre '%s' est indisponible ! \n",liv);
                    if(prend(q)) printf("'%s' '%s',Vous avez d\202ja emprunt\202 !\n",nom,prnom);
                }
            }
        }
        else
        {
            r =*te;
            while(r!=NULL)
            {
                if (r->n_emp == q->n_ord && r->rendu) s =r ;

                r=r->suit ;
            }
            ajout_dat(&j,&m,&a,s->d_limite.jour,s->d_limite.mois,s->d_limite.anne,2*q->pinalite);
            printf("L'emprunteur'%s' '%s' vous etes pinalise jusq'a %d/%d/%d \n",q->nom,q->prenom,j,m,a);
        }
    }
        if (!cot) printf("Le livre '%s' n'existe pas \n",liv) ;
        if (!ord) printf("L'empruunteur '%s' '%s' n'existe pas il faut d'abord inscrit \n",nom,prnom);


    fclose(fich);
    fclose(fil);
}

void enregistrer (struct list_livre *tete,M_emprunteur *tet,M_emprunt *te)
{//pour ne pas perdre les donn�es d'execution courante
    struct list_livre *z=tete ;
    M_emprunteur *s=tet ;
    M_emprunt *p=te ;
    int i ;
    FILE *F1=fopen("liste des livres2.txt","w") ;
    FILE *F2=fopen("liste des emprunteurs2.txt","w") ;
    FILE *F3=fopen("liste des emprunts2.txt","w") ;


    while (z !=NULL)
        {
         fprintf(F1,"%d %s %s %s %d (",z->livre.cote,z->livre.titre,z->livre.auteur,z->livre.editeur,z->livre.date_edit);
        for (i=0 ; i<z->livre.help ; i++)
       {
           fprintf(F1,"%c",z->livre.t[i]) ;
       }
        fprintf(F1,") #%s# %d\n",z->livre.resume,z->livre.disponible) ;
            z=z->next ;

       }
   while (s!=NULL)
   {
       fprintf(F2,"%s %s %s %s %d %d %d\n",nom(s),prenom(s),s->adress,telephon(s),n_ordre(s),s->prend,s->pinalite);
        s=s->suiv;
   }

   while (p !=NULL)
    {
   fprintf(F3,"%d %d %s %d %d %d %d\n",p->cot_livre,p->n_emp,p->dat_emprunt,p->d_limite.jour,p->d_limite.mois,p->d_limite.anne,p->rendu) ;
   p=p->suit ;
    }
   fclose(F1) ;
   fclose(F2) ;
   fclose(F3) ;
}

void mis_a_jour_pina(M_emprunt *tete1,M_emprunteur *tete2)
{
    int j1,j2,m1,m2,a1,a2 ;
    M_emprunt *s,*p = tete1 ;
    M_emprunteur *q = tete2 ;
    char chain[MAX];
    time_t now = time (NULL);/* lire l'heure courante */
    struct tm tm_now = *localtime (&now);/* la convertir en heure locale */

    strftime (chain, sizeof "JJ/MM/AAAA", "%d/%m/%Y", &tm_now);/*s_now contient la date de l'inscription */

    while(q!=NULL)
    {
        p = tete1 ;
        s = NULL ;
        while(p!=NULL && q->pinalite!=0)
        {
            if(p->n_emp==q->n_ord && p->rendu)
            {
                s = p ;
            }
            p=p->suit ;
        }

        if(s!=NULL)
        {
            date_ent(&j1,&m1,&a1,chain);
            ajout_dat(&j2,&m2,&a2,s->d_limite.jour,s->d_limite.mois,s->d_limite.anne,2*q->pinalite);
            if(a1>a2) q->pinalite =0 ;
            if(a1==a2 && m1>m2) q->pinalite =0 ;
            if(a1==a2 && m1==m2 && j1>j2)  q->pinalite =0 ;
        }
        q =q->suiv ;
    }
}

void ajout_dat (int *jour,int *mois,int *anne,int j,int m,int a,int n)
{//donner la date limite pour chaque emprunt
    int cal[12] ={31,28,31,30,31,30,31,31,30,31,30,31,0};

    *jour = j ;
    *mois = m ;
    *anne = a ;
    *jour = *jour + n ;
    while(*jour > cal[*mois-1])
    {
        *jour = *jour-(cal[*mois-1]);
        *mois = *mois +1 ;
        while(*mois>12)
        {
            *mois = 1 ;
            *anne = *anne + 1 ;
        }
    }
}

int verif_phon (char chain[])
{
    int test=1,i =0 ;


    while (i <= 9 && test)
    {
        if (chain[i]<48 || chain[i]>57) test = 0 ;
        i++ ;
    }
    if(chain[10]!= '#') test = 0 ;
    return test ;
}
