#include <stdio.h>
#include <stdlib.h>
#include "conio.h"

#define down 80
#define up 72
#define entr 13

void choix_menu (int *choice);   /**Procedure d'ffichage du menu qu'on parcoure avec les fleches bidirectionnelles et qui retourne le choix**/
void acc();   /**Donne la forme g�n�rale de l'application**/
void begining (); /**Page d'accueil**/
void ending(); /**Graphisme de fin**/

